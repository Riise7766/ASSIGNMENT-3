package com.example.design;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }
    public void message(View v){
        setContentView(R.layout.activity2);
    }
    public void homepage(View v){
        setContentView(R.layout.activity2);
    }
    public void login(View v){
        setContentView(R.layout.activiti1);
    }
    public void signup(View v){
        setContentView(R.layout.activity_main);
    }
}